// Borland C++ Builder
// Copyright (c) 1995, 1999 by Borland International
// All rights reserved

// (DO NOT EDIT: machine generated header) 'ExcMemMap.pas' rev: 5.00

#ifndef ExcMemMapHPP
#define ExcMemMapHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <Classes.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Excmemmap
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS EMMFileError;
class PASCALIMPLEMENTATION EMMFileError : public Sysutils::Exception 
{
	typedef Sysutils::Exception inherited;
	
public:
	#pragma option push -w-inl
	/* Exception.Create */ inline __fastcall EMMFileError(const AnsiString Msg) : Sysutils::Exception(Msg
		) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateFmt */ inline __fastcall EMMFileError(const AnsiString Msg, const System::TVarRec 
		* Args, const int Args_Size) : Sysutils::Exception(Msg, Args, Args_Size) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateRes */ inline __fastcall EMMFileError(int Ident)/* overload */ : Sysutils::Exception(
		Ident) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateResFmt */ inline __fastcall EMMFileError(int Ident, const System::TVarRec * Args
		, const int Args_Size)/* overload */ : Sysutils::Exception(Ident, Args, Args_Size) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateHelp */ inline __fastcall EMMFileError(const AnsiString Msg, int AHelpContext) : 
		Sysutils::Exception(Msg, AHelpContext) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateFmtHelp */ inline __fastcall EMMFileError(const AnsiString Msg, const System::TVarRec 
		* Args, const int Args_Size, int AHelpContext) : Sysutils::Exception(Msg, Args, Args_Size, AHelpContext
		) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateResHelp */ inline __fastcall EMMFileError(int Ident, int AHelpContext)/* overload */
		 : Sysutils::Exception(Ident, AHelpContext) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateResFmtHelp */ inline __fastcall EMMFileError(System::PResStringRec ResStringRec, 
		const System::TVarRec * Args, const int Args_Size, int AHelpContext)/* overload */ : Sysutils::Exception(
		ResStringRec, Args, Args_Size, AHelpContext) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TObject.Destroy */ inline __fastcall virtual ~EMMFileError(void) { }
	#pragma option pop
	
};


class DELPHICLASS TMMFileStream;
class PASCALIMPLEMENTATION TMMFileStream : public Classes::TStream 
{
	typedef Classes::TStream inherited;
	
private:
	unsigned FFile;
	unsigned FMode;
	unsigned FFileSize;
	unsigned FCurOffset;
	unsigned FMapping;
	void *FView;
	unsigned FViewOfs;
	unsigned FViewSize;
	unsigned FGranula;
	unsigned FMaxView;
	unsigned FReviews;
	void __fastcall ReView(unsigned DesiredOffset, unsigned DesiredDataSize);
	void * __fastcall GetRawData(unsigned Offset);
	__property void * RawData[unsigned Offset] = {read=GetRawData};
	
public:
	__fastcall TMMFileStream(AnsiString FileName, int Mode, AnsiString MapName);
	__fastcall virtual ~TMMFileStream(void);
	void * __fastcall MapData(unsigned Offset, unsigned Size);
	void __fastcall UnMapData(void);
	Byte __fastcall ReadByte(void);
	Word __fastcall ReadWord(void);
	unsigned __fastcall ReadDword(void);
	void * __fastcall ReadPointer(void);
	virtual int __fastcall Read(void *Buffer, int Count);
	virtual int __fastcall Write(const void *Buffer, int Count);
	virtual int __fastcall Seek(int Offset, Word Origin);
};


//-- var, const, procedure ---------------------------------------------------

}	/* namespace Excmemmap */
#if !defined(NO_IMPLICIT_NAMESPACE_USE)
using namespace Excmemmap;
#endif
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// ExcMemMap
