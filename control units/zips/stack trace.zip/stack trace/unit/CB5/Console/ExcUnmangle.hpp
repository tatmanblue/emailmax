// Borland C++ Builder
// Copyright (c) 1995, 1999 by Borland International
// All rights reserved

// (DO NOT EDIT: machine generated header) 'ExcUnmangle.pas' rev: 5.00

#ifndef ExcUnmangleHPP
#define ExcUnmangleHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <SysUtils.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Excunmangle
{
//-- type declarations -------------------------------------------------------
//-- var, const, procedure ---------------------------------------------------
static const Shortint UM_UNKNOWN = 0x0;
static const Shortint UM_FUNCTION = 0x1;
static const Shortint UM_CONSTRUCTOR = 0x2;
static const Shortint UM_DESTRUCTOR = 0x3;
static const Shortint UM_OPERATOR = 0x4;
static const Shortint UM_CONVERSION = 0x5;
static const Shortint UM_DATA = 0x6;
static const Shortint UM_THUNK = 0x7;
static const Shortint UM_TPDSC = 0x8;
static const Shortint UM_VTABLE = 0x9;
static const Shortint UM_VRDF_THUNK = 0xa;
static const Byte UM_KINDMASK = 0xff;
static const Word UM_QUALIFIED = 0x100;
static const Word UM_TEMPLATE = 0x200;
static const Word UM_VIRDEF_FLAG = 0x400;
static const Word UM_FRIEND_LIST = 0x800;
static const Word UM_CTCH_HNDL_TBL = 0x1000;
static const Word UM_OBJ_DEST_TBL = 0x2000;
static const Word UM_THROW_LIST = 0x4000;
static const Word UM_EXC_CTXT_TBL = 0x8000;
static const int UM_LINKER_PROC = 0x10000;
static const int UM_SPECMASK = 0x1fc00;
static const int UM_MODMASK = 0xffff00;
static const int UM_BUFOVRFLW = 0x1000000;
static const int UM_HASHTRUNC = 0x2000000;
static const int UM_ERROR = 0x4000000;
static const int UM_ERRMASK = 0x3f000000;
static const int UM_NOT_MANGLED = 0x40000000;
extern PACKAGE int __fastcall _UnMangle(char * Src, char * Dest, int MaxLen, char * QualP, char * BaseP
	, bool doArgs, bool IsDelphi);

}	/* namespace Excunmangle */
#if !defined(NO_IMPLICIT_NAMESPACE_USE)
using namespace Excunmangle;
#endif
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// ExcUnmangle
