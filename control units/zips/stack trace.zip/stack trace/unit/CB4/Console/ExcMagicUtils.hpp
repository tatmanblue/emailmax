// Borland C++ Builder
// Copyright (c) 1995, 1999 by Borland International
// All rights reserved

// (DO NOT EDIT: machine generated header) 'ExcMagicUtils.pas' rev: 4.00

#ifndef ExcMagicUtilsHPP
#define ExcMagicUtilsHPP

#pragma delphiheader begin
#pragma option push -w-
#include <SysUtils.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Excmagicutils
{
//-- type declarations -------------------------------------------------------
//-- var, const, procedure ---------------------------------------------------
extern PACKAGE bool __fastcall WriteMem(void * Address, void * NewBytes, int Size);
extern PACKAGE bool __fastcall ReadMem(void * Address, void * Dest, int Size);
extern PACKAGE int __fastcall CompareMem(void * Ptr1, void * Ptr2, int Size);
extern PACKAGE AnsiString __fastcall DumpBytes(void * Addr, int Size);
extern PACKAGE AnsiString __fastcall LocalTimeStr(void);
extern PACKAGE AnsiString __fastcall StrChar2Char(AnsiString Src, char Char1, char Char2);
extern PACKAGE void __fastcall FreeAndNil(void *Obj);

}	/* namespace Excmagicutils */
#if !defined(NO_IMPLICIT_NAMESPACE_USE)
using namespace Excmagicutils;
#endif
#pragma option pop	// -w-

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// ExcMagicUtils
